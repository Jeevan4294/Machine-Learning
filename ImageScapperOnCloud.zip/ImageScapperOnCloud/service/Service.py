import urllib.request
import urllib.parse
import urllib.error
from bs4 import BeautifulSoup as bs

class Service:

    @staticmethod
    def get_raw_html(url, header={'User-Agent':"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36"}):
        req = urllib.request.Request(url, headers=header)
        resp = urllib.request.urlopen(req)
        respData = resp.read()
        html = bs(respData, 'html.parser')
        return html

    @staticmethod
    def download_images_from_URL(imageUrlList, image_name, header={'User-Agent':"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36"}):
        masterListOfImages = []
        count = 0
        imageFiles = []
        imageTypes = []
        image_counter = 0
        for i, (img, Type) in enumerate(imageUrlList):
            try:
                if (count > 5):
                    break
                else:
                    count = count + 1
                req = urllib.request.Request(img, headers=header)
                try:
                    urllib.request.urlretrieve(img, "./static/" + image_name + str(image_counter) + ".jpg")
                    image_counter = image_counter + 1
                except Exception as e:
                    print("Image write failed:  ", e)
                    image_counter = image_counter + 1
                respData = urllib.request.urlopen(req)
                raw_img = respData.read()
                imageFiles.append(raw_img)
                imageTypes.append(Type)

            except Exception as e:
                print("could not load : " + img)
                print(e)
                count = count + 1
        masterListOfImages.append(imageFiles)
        masterListOfImages.append(imageTypes)
        return masterListOfImages