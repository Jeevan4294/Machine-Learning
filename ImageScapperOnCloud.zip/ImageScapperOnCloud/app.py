from flask_cors import CORS, cross_origin
from flask import Flask, render_template, request,jsonify
from scrapper.Image_scrapper import ImageScrapper
from service.Service import Service
from utils.Utils import Utils

app = Flask(__name__) # initialising the flask app with the name 'app'


@app.route('/')  # route for redirecting to the home page
@cross_origin()
def home():
    return render_template('index.html')


@app.route('/showImages') # route to show the images on a webpage
@cross_origin()
def show_images():
    list_of_jpg_files = Utils.list_only_specific_files('./static', 'jpg')
    print(list_of_jpg_files)
    try:
        if len(list_of_jpg_files) > 0:  # if there are images present, show them on a wen UI
            return render_template('showImage.html', user_images=list_of_jpg_files)
        else:
            # show this error message if no images are present in the static folder
            return render_template('error_page.html', error_msg='Please try with a different string')
    except Exception as e:
        print('no Images found ', e)
        return render_template('error_page.html', error_msg='Please try with a different string')


@app.route('/searchImages', methods=['GET', 'POST'])
def search_images():
    keyword = ''
    if request.method == 'POST':
        print("entered post")
        keyword = request.form['keyword']  # assigning the value of the input keyword to the variable keyword
    else:
        print("did not enter post")

    print('printing = ' + keyword)

    list_of_old_jpg_images = Utils.list_only_specific_files('./static', 'jpg')

    Utils.delete_existing_image(list_of_old_jpg_images)

    img_scraper_obj = ImageScrapper()  # instantiating the class
    image_name = '+'.join(keyword.split())
    print(image_name)
    url = img_scraper_obj.createURL(image_name)

    raw_html = Service.get_raw_html(url)

    image_url_list = img_scraper_obj.getimageUrlList(raw_html)

    Service.download_images_from_URL(image_url_list, keyword)

    return show_images()


if __name__ == "__main__":
    #app.run(host='127.0.0.1', port=8000) # port to run on local machine
    app.run(debug=True) # to run on cloud
