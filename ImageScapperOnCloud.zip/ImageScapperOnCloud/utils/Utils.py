import os


class Utils:

    @staticmethod
    def store_images(image_files, file_loc, keyword):
        if not os.path.exists(file_loc):
            os.mkdir(file_loc)
        file_loc = os.path.join(file_loc, keyword.split()[0])

        if not os.path.exists(file_loc):
            os.mkdir(file_loc)

        count = 0;
        for raw_img in image_files.keys():
            Type = 'jpg'
            counter = len([i for i in os.listdir(file_loc) if Type in i]) + 1
            print(counter)
            if len(Type) == 0:
                f = open(os.path.join(file_loc, keyword + "_" + str(counter) + ".jpg"), 'wb')
            else:
                f = open(os.path.join(file_loc, keyword + "_" + str(counter) + "." + Type), 'wb')

            f.write(image_files.get(raw_img))
            f.close()
            count += 1

    @staticmethod
    def delete_existing_image(list_of_images):
        for image in list_of_images:
            try:
                os.remove("./static/"+image)
            except Exception as e:
                print('error in deleting:  ',e)
        return 0

    @staticmethod
    def list_only_specific_files(folder_name, extension):
        list_of_jpg_files = []
        list_of_files = os.listdir(folder_name)
        print('list of files==')
        print(list_of_files)
        for file in list_of_files:
            name_array = file.split('.')
            if name_array[1] == extension:
                list_of_jpg_files.append(file)
            else:
                print('filename does not end withn jpg')
        return list_of_jpg_files
